package com.cts.bankmanagement.bo;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.EducationLoanVo;

@Component
public class ApplyEducationLoanBo {

	static Logger log = Logger.getLogger(ApplyEducationLoanBo.class);
	public final String msg1 = "Father name should not contain any special characters. Hence Loan cannot be Sanctioned";
	public final String msg2 = "Course Fee should not be greater than 20 lakhs. Hence Loan cannot be Sanctioned";
	public final String msg3 = "Please enter valid id card number, which contains min of 5 characters. Hence Loan cannot be Sanctioned";

	public EducationLoanVo generateIds(EducationLoanVo eduLoanVo) {

		log.info("inside generateIds method of ApplyEducationLoanBo class");

		// Logic for generating education loan id: Start
		Long idCardNumber = eduLoanVo.getIdCardNumber();

		log.info("idCardNumber " + idCardNumber);

		String educationLoanId = "EL-"
				+ idCardNumber.toString().substring(0, 5);

		log.info("newly generated education loan id " + educationLoanId);

		eduLoanVo.setEducationLoanId(educationLoanId);
		// Logic for generating education loan id: End

		// Logic for generating education Loan Account Number: Start
		Random rng = new Random();

		long eduLoanAccountNumber = (rng.nextLong() % 100000000000000L) + 1700000000000000L;

		log.info("Setting homeLoanAccountNumber in ApplyHomeLoanBo.generateIds");

		eduLoanVo.setEduLoanAccountNumber(eduLoanAccountNumber);

		return eduLoanVo;

		// Logic for generating education Loan Account Number: End

	}

	public boolean checkFatherName(EducationLoanVo eduLoanVo) {

		log.info("inside checkFatherName method of ApplyEducationLoanBo class");
		String fatherName = eduLoanVo.getFatherName();
		boolean fnamematch = fatherName.matches("[a-zA-z]+([ '-][a-zA-Z]+)*");
		if (!fnamematch) {
			try {
				throw new BankManagementException(msg1);
			} catch (BankManagementException e) {
				eduLoanVo.setFatherNameMessage(e.getMessage());
				return false;
			}
		}

		return true;
	}

	public boolean checkCourseFee(EducationLoanVo eduLoanVo) {

		log.info("inside checkCourseFee method of Bo class.");
		int fees = eduLoanVo.getCourseFee();

		log.info("fees is " + fees);
		if (fees > 2000000) {
			try {
				throw new BankManagementException(msg2);
			} catch (BankManagementException e) {
				eduLoanVo.setCourseFeeMessage(e.getMessage());
				return false;
			}
		} else
			return true;
	}

	public Date formatDate(String applyDate) throws ParseException {

		log.info("Entered ApplyHomeLoanBo.formatDate");

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyyy");
		java.util.Date d1 = null;

		try {
			d1 = sdf.parse(applyDate);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		Date d2 = new java.sql.Date(d1.getTime());

		log.info("Exiting ApplyHomeLoanBo.formatDate");
		return d2;

	}

	public boolean checkIdCardLength(EducationLoanVo eduLoanVo) {

		log.info("inside checkIdCardLength method of Bo class");
		if (eduLoanVo.getIdCardNumber().toString().length() < 5) {

			try {
				throw new BankManagementException(msg3);
			} catch (BankManagementException e) {
				eduLoanVo.setIdCardMessage(e.getMessage());
				return false;
			}

		}
		return true;
	}
}
