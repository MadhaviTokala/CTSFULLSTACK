package com.cts.bankmanagement.bo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.sql.Date;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

@Component
public class ApplyHomeLoanBo {

	static Logger log = Logger.getLogger(ApplyHomeLoanBo.class);

	public static final String msg = "Annual Income is not equal to 10% of Loan. Hence Loan cannot be Sanctioned";

	public HomeLoanDetailsVo generateIds(HomeLoanDetailsVo applyHomeLoanVo) {

		/* Logic to Generate Home Loan Id */

		String accountNumber = applyHomeLoanVo.getAccountNumber().toString();

		String homeLoanId = "HL-"
				+ accountNumber.substring(accountNumber.length() - 3);

		log.info("Setting homeLoanId in ApplyHomeLoanBo.generateIds");

		applyHomeLoanVo.setLoanID(homeLoanId);

		/* Logic to Generate Home Loan Account Number */

		Random rng = new Random();

		long homeLoanAccountNumber = (rng.nextLong() % 100000000000000L) + 1700000000000000L;

		log.info("Setting homeLoanAccountNumber in ApplyHomeLoanBo.generateIds");

		applyHomeLoanVo.setLoanAccountNumber(homeLoanAccountNumber);

		return applyHomeLoanVo;

	}

	public Boolean checkLoanAmount(HomeLoanDetailsVo applyHomeLoanVo) {

		final Boolean flag = false;

		log.info("Checking Account in ApplyHomeLoanBo.checkLoanAmount");

		long loanAmount = applyHomeLoanVo.getLoanAmount();

		long annualIncome = applyHomeLoanVo.getAnnualIncome();

		if (annualIncome == (loanAmount * 0.1)) {
			return flag;
		} else
			try {
				throw new BankManagementException(msg);
			} catch (BankManagementException e) {
				applyHomeLoanVo.setAnnIncomeMsg(e.getMessage());
				return true;
			}

	}

	public Date formatDate(String applyDate) throws ParseException {

		log.info("Entered ApplyHomeLoanBo.formatDate");

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyyy");
		java.util.Date d1 = null;

		try {
			d1 = sdf.parse(applyDate);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		Date d2 = new java.sql.Date(d1.getTime());

		log.info("Exiting ApplyHomeLoanBo.formatDate");
		return d2;

	}

}
