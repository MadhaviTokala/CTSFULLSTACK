package com.cts.bankmanagement.bo;

import org.springframework.stereotype.Component;


@Component
public class PerformTransactionBo{

	public Long generateTransId(){
		
			long first10 = (long) (Math.random() * 100000000L);
			String number = String.valueOf(1000000000L + first10);
			Long tId=Long.valueOf(number);
			return tId;
		} 
}

