package com.cts.bankmanagement.controller;

import java.util.Map;
import java.util.TreeMap;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.bo.ApplyEducationLoanBo;
import com.cts.bankmanagement.service.ApplyEducationLoanService;
import com.cts.bankmanagement.vo.EducationLoanVo;
import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

@Controller
public class ApplyEducationLoanController {

	static Logger log = Logger.getLogger(ApplyEducationLoanController.class);
	public final String msg = "Loan applied successfully. Your Loan Account number is ";
	private ApplyEducationLoanBo eduLoanBo;
	private ApplyEducationLoanService eduLoanService;

	@Autowired(required = true)
	public void setEduLoanBo(ApplyEducationLoanBo eduLoanBo) {
		this.eduLoanBo = eduLoanBo;
	}

	@Autowired(required = true)
	public void setEduLoanService(ApplyEducationLoanService eduLoanService) {
		this.eduLoanService = eduLoanService;
	}

	@RequestMapping("/viewApplyEducationLoanJsp")
	public ModelAndView viewEducationLoan() {
log.info("LALALALALALALALAAL");
		ModelAndView model = new ModelAndView();
		model.addObject("educationLoanVo", new EducationLoanVo());
		model.setViewName("applyeducation");
		return model;
	}

	@RequestMapping(value = "/EducationLoan/ApplyEducationLoan")
	public ModelAndView initiateEducationLoan(
			@Valid @ModelAttribute("educationLoanVo") EducationLoanVo educationLoanVo,
			BindingResult result)
			throws MySQLIntegrityConstraintViolationException {

		if (result.hasErrors()) {
			return new ModelAndView("applyeducation");
		} else {
			log.info("inside initiateEducationLoan method. ");

			if (eduLoanBo.checkFatherName(educationLoanVo)) {

				long educationLoanAccountNumber = eduLoanService
						.insertEducationLoanDetails(educationLoanVo);

				return new ModelAndView("successmessage", "msg", msg
						+ educationLoanAccountNumber);
			} else {
				return new ModelAndView("successmessage", "msg",
						educationLoanVo.getFatherNameMessage());
			}

		}

	}

	@ModelAttribute("durationMap")
	public Map<String, String> getDurationList() {
		Map<String, String> durationMap = new TreeMap<String, String>();
		durationMap.put("05", "05");
		durationMap.put("10", "10");
		return durationMap;
	}

}
