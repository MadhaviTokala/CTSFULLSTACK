package com.cts.bankmanagement.controller;

import java.util.Map;
import java.util.TreeMap;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.bo.ApplyHomeLoanBo;
import com.cts.bankmanagement.service.ApplyHomeLoanService;
import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

@Controller
public class ApplyHomeLoanController {

	static Logger log = Logger.getLogger(ApplyHomeLoanController.class);

	public static final String msg = "Loan applied successfully. Your Loan Account number is ";

	private ApplyHomeLoanService applyHomeLoanService;
	private ApplyHomeLoanBo applyHomeLoanBo;

	@Autowired(required = true)
	public void setApplyHomeLoanService(
			ApplyHomeLoanService applyHomeLoanService) {
		this.applyHomeLoanService = applyHomeLoanService;
	}

	@Autowired(required = true)
	public void setApplyHomeLoanBo(ApplyHomeLoanBo applyHomeLoanBo) {
		this.applyHomeLoanBo = applyHomeLoanBo;
	}

	@RequestMapping("/viewApplyhomeLoanJsp")
	public ModelAndView viewHomeLoan() {

		ModelAndView model = new ModelAndView();

		model.addObject("homeLoanVo", new HomeLoanDetailsVo());

		model.setViewName("applyhomeloan");

		log.info("Method-1 in controller");

		return model;

	}

	@RequestMapping(value = "/HomeLoan/applyHomeLoan", method = RequestMethod.POST)
	public ModelAndView initiateHomeLoan(
			@Valid @ModelAttribute("homeLoanVo") HomeLoanDetailsVo homeLoanVo,
			BindingResult result) {

		log.info("initiateHomeLoan Method in controller");

		if (result.hasErrors()) {

			return new ModelAndView("applyhomeloan");
		} else {

			if (applyHomeLoanBo.checkLoanAmount(homeLoanVo)) {
				return new ModelAndView("successmessage", "msg",
						homeLoanVo.getAnnIncomeMsg());
			} else {

				long homeLoanAccountNumber = applyHomeLoanService
						.insertHomeLoanDetails(homeLoanVo);

				if (homeLoanAccountNumber == 0l) {
					return new ModelAndView("successmessage", "msg",
							homeLoanVo.getUserMessage());
				} else {

					log.info("Exiting initiateHomeLoan Method of controller in Sanction Loan Block");
					return new ModelAndView("successmessage", "msg", msg
							+ homeLoanAccountNumber);

				}
			}
		}

	}

	@ModelAttribute("durationMap")
	public Map<String, String> getDurationList() {
		Map<String, String> durationMap = new TreeMap<String, String>();
		durationMap.put("05", "05");
		durationMap.put("10", "10");
		durationMap.put("15", "15");
		durationMap.put("20", "20");
		return durationMap;
	}

}
