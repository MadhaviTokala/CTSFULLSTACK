package com.cts.bankmanagement.controller;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.service.PerformTransactionService;
import com.cts.bankmanagement.vo.TransactionVO;

@Controller
public class PerformTransactionController {

	Logger LOG = Logger.getLogger(PerformTransactionController.class);

	public final String message = "Transaction Successfully Completed. The balance available in your Account is ";

	@Autowired(required = true)
	private PerformTransactionService performTransactionService;

	@RequestMapping("/performTransactionPage")
	public ModelAndView showForm() {
		LOG.info("Inside Show Method");
		return new ModelAndView("performtransaction", "transactionVO",
				new TransactionVO());
	}

	@RequestMapping(value = "doTransaction", method = RequestMethod.POST)
	public ModelAndView initiateTransaction(
			@Valid @ModelAttribute("transactionVO") TransactionVO transactionVO,
			BindingResult bindingResult) throws BankManagementException {
		LOG.info("Initiate Transaction");
		if (bindingResult.hasErrors()) {
			return new ModelAndView("performtransaction");
		}
		Double updatedBalance = performTransactionService
				.updateTransactionDetails(transactionVO);
		if (updatedBalance == 0.0) {

			return new ModelAndView("successmessage", "msg",
					transactionVO.getUserMessage());
		}
		LOG.info("Updated Balance " + updatedBalance);

		return new ModelAndView("successmessage", "msg", message + updatedBalance);

	}

}
