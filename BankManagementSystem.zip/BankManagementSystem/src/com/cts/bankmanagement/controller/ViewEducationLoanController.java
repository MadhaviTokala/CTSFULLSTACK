package com.cts.bankmanagement.controller;

import javax.ws.rs.FormParam;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.service.ViewEducationLoanService;
import com.cts.bankmanagement.vo.EducationLoanVo;

@RestController
public class ViewEducationLoanController {

	static Logger log = Logger.getLogger(ViewEducationLoanController.class);

	private ViewEducationLoanService eduLoanService;

	@Autowired(required = true)
	public void setEduLoanService(ViewEducationLoanService eduLoanService) {
		this.eduLoanService = eduLoanService;
	}

	@RequestMapping("/viewGetEducationLoanJsp")
	public ModelAndView viewEducationLoanDetails() {

		ModelAndView model = new ModelAndView();
		model.addObject("educationLoanVo", new EducationLoanVo());
		model.setViewName("retrieveeducationloan");
		return model;
	}

	@RequestMapping(value = "/EducationLoan/ViewEducationLoan", method = RequestMethod.GET)
	public ModelAndView searchEducationLoanDetails(
			@FormParam("educationLoanId") String educationLoanId,
			@FormParam("accountNumber") Long accountNumber) {

		log.info("idNumber is : " + educationLoanId);
		log.info("accountNumber is : " + accountNumber);

		ModelAndView model = new ModelAndView();

		EducationLoanVo educationLoanVo = eduLoanService
				.retriveEducationLoanDetails(educationLoanId, accountNumber);

		if (educationLoanVo.getAccountHolderName() == null) {
			log.info("inside if condition ");

			model.addObject("message", educationLoanVo.getUserMessage());
		}

		else {

			model.addObject("eduLoanVo", educationLoanVo);
		}

		model.setViewName("retrieveeducationloan");

		return model;
	}

}
