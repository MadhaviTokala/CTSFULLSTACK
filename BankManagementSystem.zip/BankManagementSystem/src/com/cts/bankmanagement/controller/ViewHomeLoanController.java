package com.cts.bankmanagement.controller;

import javax.ws.rs.FormParam;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.service.ViewHomeLoanService;
import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

@RestController
public class ViewHomeLoanController {

	static Logger log = Logger.getLogger(ViewHomeLoanController.class);

	public static final String enterLogMsg = "Entered";
	public static final String exitLogMsg = "Exited";

	private ViewHomeLoanService viewHomeLoanService;

	@Autowired
	public void setViewHomeLoanService(ViewHomeLoanService viewHomeLoanService) {
		this.viewHomeLoanService = viewHomeLoanService;
	}

	@RequestMapping("/viewRetrievehomeLoanJsp")
	public ModelAndView viewHomeLoan() {

		log.info(enterLogMsg);

		ModelAndView mv = new ModelAndView();

		mv.addObject("retrieveHomeLoanVo", new HomeLoanDetailsVo());

		mv.setViewName("retrievehomeloan");

		log.info(exitLogMsg);

		return mv;

	}

	@RequestMapping(value = "/HomeLoan/retrieveHomeLoan", method = RequestMethod.GET)
	public ModelAndView searchHomeLoanDetails(
			@FormParam("loanID") String loanID,
			@FormParam("loanAccountNumber") Long loanAccountNumber) {

		log.info(enterLogMsg);

		ModelAndView mv = new ModelAndView();

		HomeLoanDetailsVo homeLoanVo = viewHomeLoanService
				.retrieveHomeLoanDetails(loanID, loanAccountNumber);

		if (homeLoanVo.getAccountHolderName() == null && homeLoanVo.getUserMessage()!=null) {
			mv.addObject("message", homeLoanVo.getUserMessage());
		} else {
			mv.addObject("homeLoanVo", homeLoanVo);
		}

		mv.setViewName("retrievehomeloan");

		log.info(exitLogMsg);

		return mv;

	}

}
