package com.cts.bankmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.FormParam;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.service.ViewTransactionService;
import com.cts.bankmanagement.vo.TransactionVO;

@RestController
public class ViewTransactionController {

	Logger logger = Logger.getLogger(ViewTransactionController.class);

	public final String message = "No Records found";

	@Autowired
	private ViewTransactionService viewTransactionService;

	@RequestMapping("/viewTransactionSearch")
	public ModelAndView showForm() {
		logger.info("Inside Show Method");
		return new ModelAndView("viewtransaction", "transactionVO",
				new TransactionVO());
	}

	@RequestMapping(value = "searchTransaction", method = RequestMethod.GET, produces = "application/json")
	public ModelAndView searchUserTransaction(
			@FormParam("accountNumber") Long accountNumber,
			@FormParam("transactionId") Long transactionId) {

		logger.info("Inside View Controller method");
		List<TransactionVO> transactionList = new ArrayList<TransactionVO>();

		ModelAndView model = new ModelAndView();

		transactionList = viewTransactionService.retrieveTransactionDetails(
				accountNumber, transactionId);

		if (transactionList.isEmpty()) {

			try {
				throw new BankManagementException(message);
			} catch (BankManagementException e) {

				model.addObject("message", e.getMessage());
				model.setViewName("viewtransaction");

				logger.info("In No records condition");

				return model;

			}

		} else {

			model.addObject("transactionList", transactionList);
			model.setViewName("viewtransaction");

			logger.info("end of view");

			return model;
		}

	}

}
