package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.vo.EducationLoanVo;

public interface ApplyEducationLoanDAO {
	
	public Long insertEducationLoanDetails(EducationLoanVo eduLoanVo);

}
