package com.cts.bankmanagement.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.bo.ApplyEducationLoanBo;
import com.cts.bankmanagement.entity.EducationLoanEntity;
import com.cts.bankmanagement.vo.EducationLoanVo;

@Repository
public class ApplyEducationLoanDAOImpl implements ApplyEducationLoanDAO{
	
	static Logger log = Logger.getLogger(ApplyEducationLoanDAOImpl.class);
	public final String logInfo = "inside insertEducationLoanDetails method of ApplyEducationLoanDAOImpl";
	
	private SessionFactory sessionFactory;
	private ApplyEducationLoanBo eduLoanBo;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Autowired(required = true)
	public void setApplyEducationLoanBo(ApplyEducationLoanBo applyEducationLoanBo) {
		this.eduLoanBo = applyEducationLoanBo;
	}

	@Override
	public Long insertEducationLoanDetails(EducationLoanVo eduLoanVo){
		
		log.info(logInfo);
		EducationLoanEntity eduLoanEntity = new EducationLoanEntity();
		
		eduLoanVo = eduLoanBo.generateIds(eduLoanVo);
		eduLoanEntity.setAccountNumber(eduLoanVo.getAccountNumber());
		eduLoanEntity.setEducationLoanId(eduLoanVo.getEducationLoanId());
		eduLoanEntity.setEduLoanAccountNumber(eduLoanVo.getEduLoanAccountNumber());
		eduLoanEntity.setEduLoanAmount(eduLoanVo.getEduLoanAmount());
		
		try {
			eduLoanEntity.setEduLoanApplyDate(eduLoanBo.formatDate(eduLoanVo.getEduLoanApplyDate()));
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		
		eduLoanEntity.setEduLoanDuration(eduLoanVo.getEduLoanDuration());
		eduLoanEntity.setFatherAnnualIncome(eduLoanVo.getFatherAnnualIncome());
		eduLoanEntity.setFatherName(eduLoanVo.getFatherName());
		eduLoanEntity.setCourseName(eduLoanVo.getCourseName());
		eduLoanEntity.setCourseFee(eduLoanVo.getCourseFee());
		eduLoanEntity.setIdCardNumber(eduLoanVo.getIdCardNumber());
		
		sessionFactory.getCurrentSession().save(eduLoanEntity);
		
		return eduLoanVo.getEduLoanAccountNumber();
	}
}
