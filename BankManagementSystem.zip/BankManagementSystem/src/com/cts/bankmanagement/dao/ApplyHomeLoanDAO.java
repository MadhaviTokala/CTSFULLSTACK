package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

public interface ApplyHomeLoanDAO {

	public Long insertHomeLoanDetails(HomeLoanDetailsVo applyHomeLoanVo);

	

}
