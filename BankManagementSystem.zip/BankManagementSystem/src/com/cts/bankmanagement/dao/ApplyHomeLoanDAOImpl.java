package com.cts.bankmanagement.dao;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.bo.ApplyHomeLoanBo;
import com.cts.bankmanagement.entity.HomeLoanDetailsEntity;
import com.cts.bankmanagement.entity.UserDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

@Repository
public class ApplyHomeLoanDAOImpl implements ApplyHomeLoanDAO {

	static Logger log = Logger.getLogger(ApplyHomeLoanDAOImpl.class);

	public final String msg = "In order to apply Home Loan you need to have an account. Please create an Account to avail services.";
	public final String logInfo1 = "Entered ApplyHomeLoanDAOImpl.insertHomeLoanDetails";
	public final String logInfo2 = "Insertion Successful in ApplyHomeLoanDAOImpl.insertHomeLoanDetails";

	private SessionFactory sessionFactory;
	private ApplyHomeLoanBo applyHomeLoanBo;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Autowired(required = true)
	public void setApplyHomeLoanBo(ApplyHomeLoanBo applyHomeLoanBo) {
		this.applyHomeLoanBo = applyHomeLoanBo;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Long insertHomeLoanDetails(HomeLoanDetailsVo applyHomeLoanVo) {

		log.info(logInfo1);

		HomeLoanDetailsEntity applyHomeLoanEntity = new HomeLoanDetailsEntity();

		final long returnValue = 0l;

		final String hql = "FROM UserDetailsEntity WHERE accountNumber= :ACCOUNT_NUMBER";

		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		query.setParameter("ACCOUNT_NUMBER", applyHomeLoanVo.getAccountNumber());

		List<UserDetailsEntity> userList = query.list();

		if (userList.isEmpty()) {

			try {
				throw new BankManagementException(msg);
			} catch (BankManagementException e) {
				applyHomeLoanVo.setUserMessage(e.getMessage());
				return returnValue;
			}

		} else {

			applyHomeLoanVo = applyHomeLoanBo.generateIds(applyHomeLoanVo);

			try {
				applyHomeLoanEntity.setHomeLoanId(applyHomeLoanVo.getLoanID());
			} catch (Exception e1) {

				e1.printStackTrace();
			}

			applyHomeLoanEntity.setAccountNumber(applyHomeLoanVo
					.getAccountNumber());

			applyHomeLoanEntity.setHomeLoanAccountNumber(applyHomeLoanVo
					.getLoanAccountNumber());
			applyHomeLoanEntity.setAnnualIncome(applyHomeLoanVo
					.getAnnualIncome());
			applyHomeLoanEntity
					.setCompanyName(applyHomeLoanVo.getCompanyName());
			applyHomeLoanEntity
					.setDesignation(applyHomeLoanVo.getDesignation());
			applyHomeLoanEntity.setExpCurrentComapny(applyHomeLoanVo
					.getExpCurrentComapny());
			applyHomeLoanEntity.setLoanAmount(applyHomeLoanVo.getLoanAmount());

			try {

				applyHomeLoanEntity.setLoanApplyDate(applyHomeLoanBo
						.formatDate(applyHomeLoanVo.getLoanApplyDate()));
			} catch (ParseException e) {
				e.printStackTrace();
			}

			applyHomeLoanEntity.setLoanDuration(applyHomeLoanVo
					.getLoanDuration());
			applyHomeLoanEntity.setTotalExp(applyHomeLoanVo.getTotalExp());

			sessionFactory.getCurrentSession().save(applyHomeLoanEntity);

			log.info(logInfo2);

			return applyHomeLoanVo.getLoanAccountNumber();

		}

	}

}
