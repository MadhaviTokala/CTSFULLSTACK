package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

public interface PerformTransactionDAO {
	public Double updateTransactionDetails(TransactionVO transactionVO) throws BankManagementException;

}
