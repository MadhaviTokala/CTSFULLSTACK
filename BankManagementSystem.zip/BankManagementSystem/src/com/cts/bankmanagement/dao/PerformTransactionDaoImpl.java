package com.cts.bankmanagement.dao;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.bo.PerformTransactionBo;
import com.cts.bankmanagement.entity.TransactionDetailsEntity;
import com.cts.bankmanagement.entity.UserDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

@Repository
public class PerformTransactionDaoImpl implements PerformTransactionDAO {

	Logger LOG = Logger.getLogger(PerformTransactionDaoImpl.class);

	public final String message = "Remaining balance must be greater than the 5000 Rupees.";

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private PerformTransactionBo performTransactionBO;

	public Double updateTransactionDetails(TransactionVO transactionVO)
			throws BankManagementException {
		double updatedBalance = 0;

		UserDetailsEntity userDetails = (UserDetailsEntity) sessionFactory
				.getCurrentSession().get(UserDetailsEntity.class,
						transactionVO.getAccountNumber());

		LOG.info("In DAO Class " + userDetails.getAccountNumber());

		if (userDetails != null) {

			TransactionDetailsEntity transactionDetails = new TransactionDetailsEntity();

			Long transId = performTransactionBO.generateTransId();
			transactionDetails.setTransactionId(transId);
			transactionDetails.setAccountNumber(transactionVO
					.getAccountNumber());
			transactionDetails.setTransactionAmount(transactionVO
					.getTransactionAmount());
			transactionDetails.setTransactionType(transactionVO
					.getTransactionType());
			transactionDetails.setTransactionDescription(transactionVO
					.getTransactionDescription());

			if (transactionDetails.getTransactionType().equalsIgnoreCase(
					"Withdraw")
					&& userDetails.getAccountType().equalsIgnoreCase("Savings")
					&& userDetails.getAccountBalance() < 5000) {
				try {
					throw new BankManagementException(message);
				} catch (Exception e) {
					transactionVO.setUserMessage(e.getMessage());
					return updatedBalance;
				}

			} else {
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				session.save(transactionDetails);
				tx.commit();
				session.close();
				if (transactionDetails.getTransactionType().equalsIgnoreCase(
						"Deposit")) {

					updatedBalance = (double) (userDetails.getAccountBalance() + transactionDetails
							.getTransactionAmount());

				} else if (transactionDetails.getTransactionType()
						.equalsIgnoreCase("Withdraw")) {

					updatedBalance = (double) (userDetails.getAccountBalance() - transactionDetails
							.getTransactionAmount());
				}
			}
		}
		Long accountBalance = (long) updatedBalance;
		userDetails.setAccountBalance(accountBalance);
		return updatedBalance;
	}
}
