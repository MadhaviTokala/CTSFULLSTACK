package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.vo.EducationLoanVo;

public interface ViewEducationLoanDAO {
	
	public EducationLoanVo retrieveEducationLoanDetails(String educationLoanid, Long accountNumber);

}
