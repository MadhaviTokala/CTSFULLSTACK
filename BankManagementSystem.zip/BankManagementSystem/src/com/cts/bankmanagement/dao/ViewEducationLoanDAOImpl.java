package com.cts.bankmanagement.dao;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.entity.EducationLoanEntity;
import com.cts.bankmanagement.entity.UserDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.EducationLoanVo;

@Repository
public class ViewEducationLoanDAOImpl implements ViewEducationLoanDAO {

	static Logger log = Logger.getLogger(ViewEducationLoanDAOImpl.class);

	public final String message = "No Records found";

	private SessionFactory sessionFactory;

	@Autowired(required = true)
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public EducationLoanVo retrieveEducationLoanDetails(String educationLoanid,
			Long accountNumber) {

		log.info("education Loan id is " + educationLoanid
				+ "account number is " + accountNumber);

		EducationLoanVo eduLoanVo = new EducationLoanVo();

		EducationLoanEntity eduLoanEntity = new EducationLoanEntity();
		UserDetailsEntity userEntity = new UserDetailsEntity();

		if (educationLoanid.length() > 0) {
			eduLoanEntity = (EducationLoanEntity) sessionFactory
					.getCurrentSession().get(EducationLoanEntity.class,
							educationLoanid);
		}

		else if (educationLoanid.length() <= 0 && accountNumber != null) {
			log.info("inside else block.");
			Query query = sessionFactory
					.getCurrentSession()
					.createQuery(
							"FROM EducationLoanEntity WHERE accountNumber= :ACCOUNT_NUMBER");
			query.setParameter("ACCOUNT_NUMBER", accountNumber);

			eduLoanEntity = (EducationLoanEntity) query.uniqueResult();

		}

		if (eduLoanVo != null) {

			log.info("displaLoanVo is not null and account number is "
					+ eduLoanVo.getAccountNumber());

			if (eduLoanEntity == null) {
				try {
					throw new BankManagementException(message);
				} catch (BankManagementException e) {
					eduLoanVo.setUserMessage(e.getMessage());
					return eduLoanVo;
				}
			} else {

				userEntity = (UserDetailsEntity) sessionFactory
						.getCurrentSession().get(UserDetailsEntity.class,
								eduLoanEntity.getAccountNumber());

				eduLoanVo.setAccountHolderName(userEntity
						.getAccountHolderName());
				eduLoanVo.setAccountNumber(eduLoanEntity.getAccountNumber());
				eduLoanVo.setCourseName(eduLoanEntity.getCourseName());
				eduLoanVo
						.setEducationLoanId(eduLoanEntity.getEducationLoanId());
				eduLoanVo.setFatherName(eduLoanEntity.getFatherName());
				eduLoanVo.setEduLoanAmount(eduLoanEntity.getEduLoanAmount());
			}
		}

		return eduLoanVo;
	}

}
