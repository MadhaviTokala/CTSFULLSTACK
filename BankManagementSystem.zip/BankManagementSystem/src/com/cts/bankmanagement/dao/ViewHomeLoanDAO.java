package com.cts.bankmanagement.dao;


import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

public interface ViewHomeLoanDAO {
	
	public HomeLoanDetailsVo retrieveHomeLoanDetails(String loanID,Long loanAccountNumber);

}
