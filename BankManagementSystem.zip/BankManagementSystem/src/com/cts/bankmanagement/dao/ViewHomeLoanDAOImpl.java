package com.cts.bankmanagement.dao;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.entity.HomeLoanDetailsEntity;
import com.cts.bankmanagement.entity.UserDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;

import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

@Repository
public class ViewHomeLoanDAOImpl implements ViewHomeLoanDAO {

	static Logger log = Logger.getLogger(ViewHomeLoanDAOImpl.class);

	public final String logInfo1 = "Entered retrieveHomeLoanDetails Method";
	public final String logInfo2 = "Fetching Successful";

	public static final String msg = "No records found";

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public HomeLoanDetailsVo retrieveHomeLoanDetails(String loanID,
			Long loanAccountNumber) {

		log.info(logInfo1);

		HomeLoanDetailsVo homeLoanVo = new HomeLoanDetailsVo();
		HomeLoanDetailsEntity homeLoanDetailsEntity = new HomeLoanDetailsEntity();
		UserDetailsEntity userDetailsEntity = new UserDetailsEntity();

		if (!loanID.isEmpty()) {

			homeLoanDetailsEntity = (HomeLoanDetailsEntity) sessionFactory
					.getCurrentSession().get(HomeLoanDetailsEntity.class,
							loanID);

		} else if (loanID.isEmpty() && loanAccountNumber != null) {

			final String homeLoanDetailsHql = "FROM HomeLoanDetailsEntity  WHERE homeLoanAccountNumber= :homeLoanAccountNumber";

			Query query = sessionFactory.getCurrentSession().createQuery(
					homeLoanDetailsHql);

			query.setParameter("homeLoanAccountNumber", loanAccountNumber);

			homeLoanDetailsEntity = (HomeLoanDetailsEntity) query
					.uniqueResult();

		}

		if (homeLoanDetailsEntity == null) {
			try {
				throw new BankManagementException(msg);
			} catch (BankManagementException e) {
				homeLoanVo.setUserMessage(e.getMessage());
				return homeLoanVo;
			}

		} else {

			userDetailsEntity = (com.cts.bankmanagement.entity.UserDetailsEntity) sessionFactory
					.getCurrentSession().get(UserDetailsEntity.class,
							homeLoanDetailsEntity.getAccountNumber());

			homeLoanVo.setAccountHolderName(userDetailsEntity
					.getAccountHolderName());
			homeLoanVo.setCompanyName(homeLoanDetailsEntity.getCompanyName());
			homeLoanVo.setDesignation(homeLoanDetailsEntity.getDesignation());
			homeLoanVo.setLoanAccountNumber(homeLoanDetailsEntity
					.getHomeLoanAccountNumber());
			homeLoanVo.setLoanAmount(homeLoanDetailsEntity.getLoanAmount());
			homeLoanVo.setLoanID(homeLoanDetailsEntity.getHomeLoanId());

			log.info(logInfo2);

			return homeLoanVo;

		}
	}
}
