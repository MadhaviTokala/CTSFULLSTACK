package com.cts.bankmanagement.dao;

import java.util.List;

import com.cts.bankmanagement.vo.TransactionVO;

public interface ViewTransactionDAO {

	
	public List<TransactionVO> retrieveTransactionDetails(Long accountNumber,Long transactionId);
}
