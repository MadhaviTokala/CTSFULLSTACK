package com.cts.bankmanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.vo.TransactionVO;

@Repository
public class ViewTransactionDaoImpl implements ViewTransactionDAO {

	Logger log = Logger.getLogger(ViewTransactionDaoImpl.class);

	public final String logInfo1 = "Entered retrieveTransactionDetails Method";
	public final String logInfo2 = "Fetching Successful";

	@Autowired(required = true)
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public List<TransactionVO> retrieveTransactionDetails(Long accountNumber,
			Long transactionId) {

		log.info(logInfo1);

		List<TransactionVO> transactionList = new ArrayList<TransactionVO>();

		if (accountNumber != null) {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			transactionList = session
					.createQuery(
							"from TransactionDetailsEntity t where t.accountNumber=:accountNumber")
					.setParameter("accountNumber", accountNumber).list();

			tx.commit();
			session.close();

			log.info(logInfo2);

			return transactionList;

		} else if (transactionId != null && accountNumber == null) {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			transactionList = session
					.createQuery(
							"from TransactionDetailsEntity t where t.transactionId=:transactionId")
					.setParameter("transactionId", transactionId).list();
			tx.commit();
			session.close();

			log.info(logInfo2);

			return transactionList;
		}

		return null;

	}

}
