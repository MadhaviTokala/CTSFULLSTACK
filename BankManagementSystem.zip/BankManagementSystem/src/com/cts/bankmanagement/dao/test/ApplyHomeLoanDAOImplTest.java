package com.cts.bankmanagement.dao.test;



import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cts.bankmanagement.entity.HomeLoanDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;



@ContextConfiguration(locations="classpath:spring-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ApplyHomeLoanDAOImplTest {

	SessionFactory sessionFactory;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

    @Test
    @Transactional()
    @Rollback(true)
    public void testInsertHomeLoanDetails() throws BankManagementException{
    	
    HomeLoanDetailsEntity homeLoanEntity = (HomeLoanDetailsEntity) sessionFactory.getCurrentSession().get(HomeLoanDetailsEntity.class,"HL-020");
    	
    	Assert.assertEquals(16,homeLoanEntity.getAccountNumber().toString().length());
    	
    	
    }	
    	
    
}
