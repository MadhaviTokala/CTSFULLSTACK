package com.cts.bankmanagement.dao.test;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cts.bankmanagement.dao.PerformTransactionDaoImpl;
import com.cts.bankmanagement.entity.UserDetailsEntity;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

@ContextConfiguration(locations="classpath:spring-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class PerformTransactionDaoTest {
	
	@Autowired
	private PerformTransactionDaoImpl performTransactionDAOImpl;
	
	@Autowired(required=true)
	private SessionFactory sessionFactory;
	
	@Transactional
	@Rollback(true)
	@Test
	public void testUpdateTransactionDetails()  {
		
		try {
		TransactionVO transactionVO=new TransactionVO();
		transactionVO.setAccountNumber(1234567890123456l);
		transactionVO.setTransactionAmount(4501l);
		transactionVO.setTransactionDescription("madhu");
		transactionVO.setTransactionType("Deposit");
		Double d;
		
			d = performTransactionDAOImpl.updateTransactionDetails(transactionVO);
			UserDetailsEntity userDetails=(UserDetailsEntity) sessionFactory.getCurrentSession().get(UserDetailsEntity.class,1234567890123456l);
			Assert.assertEquals(Long.valueOf(d.longValue()), userDetails.getAccountBalance());
		} catch (BankManagementException e) {
			e.printStackTrace();
		}
		
}
	
}
