package com.cts.bankmanagement.dao.test;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cts.bankmanagement.entity.EducationLoanEntity;


@ContextConfiguration(locations="classpath:spring-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ViewEducationLoanDAOImplTest {
private SessionFactory sessionFactory;
@Autowired
public void setSessionFactory(SessionFactory sessionFactory) {
this.sessionFactory = sessionFactory;
}
@Test
@Transactional
@Rollback(true)
public void testRetrieveEducationLoanDetails() {
EducationLoanEntity eduLoanEntity = (EducationLoanEntity) sessionFactory.getCurrentSession().get(EducationLoanEntity.class, "EL-12365");
Assert.assertEquals(16, eduLoanEntity.getAccountNumber().toString().length());
}

}



