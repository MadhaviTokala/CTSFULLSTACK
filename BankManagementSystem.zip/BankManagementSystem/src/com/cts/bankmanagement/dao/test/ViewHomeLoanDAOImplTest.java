package com.cts.bankmanagement.dao.test;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cts.bankmanagement.dao.ViewHomeLoanDAO;
import com.cts.bankmanagement.vo.HomeLoanDetailsVo;


@ContextConfiguration(locations="classpath:spring-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ViewHomeLoanDAOImplTest {

	
	private ViewHomeLoanDAO viewHomeLoanDAO;
	
	@Autowired(required=true)
	public void setViewHomeLoanDAO(ViewHomeLoanDAO viewHomeLoanDAO) {
		this.viewHomeLoanDAO = viewHomeLoanDAO;
	}


	@Test
    @Transactional()
    @Rollback(true)
	public void testRetrieveHomeLoanDetails() {
		
		HomeLoanDetailsVo homeLoanDetailsVo = viewHomeLoanDAO.retrieveHomeLoanDetails("HL-010", 1612514775672389l);
		
		Assert.assertEquals(16,homeLoanDetailsVo.getLoanAccountNumber().toString().length());
		
	}

}
