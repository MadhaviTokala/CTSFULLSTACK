package com.cts.bankmanagement.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "EDUCATION_LOAN_DETAILS")
public class EducationLoanEntity {
	
	@Id
	@Column(name = "EDUCATION_LOAN_ID")
	@NotNull(message = "Education Loan should not be balnk.")
	private String educationLoanId;
	
	@Column(name = "ACCOUNT_NUMBER")
	@NotNull(message = "Account Number should not be blank.")
	private Long accountNumber;
	
	@Column(name = "EDU_LOAN_ACCOUNT_NUMBER")
	@NotNull(message = "Education Loan Account Number should not be blank.")
	private Long eduLoanAccountNumber;
	
	@Column(name = "EDU_LOAN_AMOUNT")
	@NotNull(message = "Education Loan Amount should not be blank.")
	private Long eduLoanAmount;
	
	@Column(name = "EDU_LOAN_APPLY_DATE")
	@NotNull(message = "Education Loan Applt Date should not be blank.")
	private Date eduLoanApplyDate;
	
	@Column(name = "EDU_LOAN_DURATION")
	@NotNull(message = "Education Loan Duration should not be blank.")
	private Integer eduLoanDuration;
	
	@Column(name = "FATHER_ANNUAL_INCOME")
	@NotNull(message = "Father's Annual Income should not be blank.")
	private Integer fatherAnnualIncome;
	
	@Column(name = "FATHER_NAME")
	@NotNull(message = "Father's Name should not be blank.")
	private String fatherName;
	
	@Column(name = "COURSE_FEE")
	@NotNull(message = "Course Fee should not be blank.")
	private Integer courseFee;
	
	@Column(name = "COURSE_NAME")
	@NotNull(message = "Course Name should not be blank.")
	private String courseName;
	
	@Column(name = "ID_CARD_NUMBER")
	@NotNull(message = "Id Card Number should not be blank.")
	private Long idCardNumber;

	public String getEducationLoanId() {
		return educationLoanId;
	}

	public void setEducationLoanId(String educationLoanId) {
		this.educationLoanId = educationLoanId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getEduLoanAccountNumber() {
		return eduLoanAccountNumber;
	}

	public void setEduLoanAccountNumber(Long eduLoanAccountNumber) {
		this.eduLoanAccountNumber = eduLoanAccountNumber;
	}

	public Long getEduLoanAmount() {
		return eduLoanAmount;
	}

	public void setEduLoanAmount(Long eduLoanAmount) {
		this.eduLoanAmount = eduLoanAmount;
	}

	public Date getEduLoanApplyDate() {
		return eduLoanApplyDate;
	}

	public void setEduLoanApplyDate(Date eduLoanApplyDate) {
		this.eduLoanApplyDate = eduLoanApplyDate;
	}

	public Integer getEduLoanDuration() {
		return eduLoanDuration;
	}

	public void setEduLoanDuration(Integer eduLoanDuration) {
		this.eduLoanDuration = eduLoanDuration;
	}

	public Integer getFatherAnnualIncome() {
		return fatherAnnualIncome;
	}

	public void setFatherAnnualIncome(Integer fatherAnnualIncome) {
		this.fatherAnnualIncome = fatherAnnualIncome;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Integer getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(Integer courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Long getIdCardNumber() {
		return idCardNumber;
	}

	public void setIdCardNumber(Long idCardNumber) {
		this.idCardNumber = idCardNumber;
	}
	
	
	

}
