package com.cts.bankmanagement.entity;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "HOME_LOAN_DETAILS")
public class HomeLoanDetailsEntity {

	@Id
	@Column(name = "HOME_LOAN_ID")
	@NotNull
	private String homeLoanId;

	@Column(name = "ACCOUNT_NUMBER")
	@NotNull(message = "Account Number should not be blank.")
	private Long accountNumber;

	@Column(name = "HOME_LOAN_ACCOUNT_NUMBER")
	@NotNull(message = "Home Loan Account Number should not be blank.")
	private Long homeLoanAccountNumber;

	@Column(name = "LOAN_AMOUNT")
	@NotNull(message = "Loan Amount should not be blank.")
	private Long loanAmount;

	@Column(name = "LOAN_APPLY_DATE")
	@NotNull(message = "Loan Apply Date should not be blank.")
	private Date loanApplyDate;

	@Column(name = "LOAN_DURATION")
	@NotNull(message = "Loan Duration should not be blank.")
	private Integer loanDuration;

	@Column(name = "ANNUAL_INCOME")
	@NotNull(message = "Annual Income should not be blank.")
	private Long annualIncome;

	@Column(name = "COMP_NAME")
	@NotNull(message = "Company Name should not be blank.")
	private String companyName;

	@Column(name = "DESIGNATION")
	@NotNull(message = "Quantity should not be blank.")
	private String designation;

	@Column(name = "TOTAL_EXP")
	@NotNull(message = "Total Experience should not be blank.")
	private Integer totalExp;

	@Column(name = "EXP_CURRENT_COMP")
	@NotNull(message = "Experience With Current Comapny should not be blank.")
	private Integer expCurrentComapny;


	public String getHomeLoanId() {
		return homeLoanId;
	}

	public void setHomeLoanId(String homeLoanId) {
		this.homeLoanId = homeLoanId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Integer getLoanDuration() {
		return loanDuration;
	}

	public Date getLoanApplyDate() {
		return loanApplyDate;
	}

	public void setLoanApplyDate(Date loanApplyDate) {
		this.loanApplyDate = loanApplyDate;
	}

	public void setLoanDuration(Integer loanDuration) {
		this.loanDuration = loanDuration;
	}

	public Long getHomeLoanAccountNumber() {
		return homeLoanAccountNumber;
	}

	public void setHomeLoanAccountNumber(Long homeLoanAccountNumber) {
		this.homeLoanAccountNumber = homeLoanAccountNumber;
	}

	public Long getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Long loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Long getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(Long annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Integer getTotalExp() {
		return totalExp;
	}

	public void setTotalExp(Integer totalExp) {
		this.totalExp = totalExp;
	}

	public Integer getExpCurrentComapny() {
		return expCurrentComapny;
	}

	public void setExpCurrentComapny(Integer expCurrentComapny) {
		this.expCurrentComapny = expCurrentComapny;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("HomeLoanDetailsEntity [homeLoanId=");
		builder.append(homeLoanId);
		builder.append(", accountNumber=");
		builder.append(accountNumber);
		builder.append(", homeLoanAccountNumber=");
		builder.append(homeLoanAccountNumber);
		builder.append(", loanAmount=");
		builder.append(loanAmount);
		builder.append(", loanApplyDate=");
		builder.append(loanApplyDate);
		builder.append(", loanDuration=");
		builder.append(loanDuration);
		builder.append(", annualIncome=");
		builder.append(annualIncome);
		builder.append(", companyName=");
		builder.append(companyName);
		builder.append(", designation=");
		builder.append(designation);
		builder.append(", totalExp=");
		builder.append(totalExp);
		builder.append(", expCurrentComapny=");
		builder.append(expCurrentComapny);
		builder.append("]");
		return builder.toString();
	}

	
	
	
}
