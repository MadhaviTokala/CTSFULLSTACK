package com.cts.bankmanagement.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TRANSACTION_DETAILS")
public class TransactionDetailsEntity {

	@Id
	@Column(name="TRANSACTION_ID")
	
	private Long transactionId;
	
	
	@Column(name="ACCOUNT_NUMBER")
	private Long accountNumber;
	
	@Column(name="TRANSACTION_DESCRIPTION")
	private String transactionDescription;
	
	
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@Column(name="TRANSACTION_ACCOUNT")
	private Long transactionAmount;

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Long getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Long transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


}
