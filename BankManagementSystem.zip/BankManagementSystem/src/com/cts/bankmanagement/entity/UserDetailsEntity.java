package com.cts.bankmanagement.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Configuration;

@Entity
@Table(name = "USER_DETAILS")
@Configuration
public class UserDetailsEntity {
	
	
		@Id
		@Column(name = "ACCOUNT_NUMBER")
		@NotNull(message = "Account Number should not be blank.")
		private Long accountNumber;

		@Column(name = "ACCOUNT_TYPE")
		@NotNull(message = "Account Type should not be blank.")
		private String accountType;
		
		@Column(name = "ACCOUNT_HOLDER_NAME")
		@NotNull(message = "Account Holder Name should not be blank.")
		private String accountHolderName ;

		@Column(name = "ACCOUNT_BALANCE")
		@NotNull(message = "Account Balance should not be blank.")
		private Long accountBalance ;

		public Long getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(Long accountNumber) {
			this.accountNumber = accountNumber;
		}

		public String getAccountType() {
			return accountType;
		}

		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}

		public String getAccountHolderName() {
			return accountHolderName;
		}

		public void setAccountHolderName(String accountHolderName) {
			this.accountHolderName = accountHolderName;
		}

		public Long getAccountBalance() {
			return accountBalance;
		}

		public void setAccountBalance(Long accountBalance) {
			this.accountBalance = accountBalance;
		}
		

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("UserDetailsEntity [accountNumber=");
			builder.append(accountNumber);
			builder.append(", accountType=");
			builder.append(accountType);
			builder.append(", accountHolderName=");
			builder.append(accountHolderName);
			builder.append(", accountBalance=");
			builder.append(accountBalance);
			builder.append("]");
			return builder.toString();
		}
		
		
		
}
