package com.cts.bankmanagement.exception;

import org.apache.log4j.Logger;



@SuppressWarnings("serial")
public class BankManagementException extends RuntimeException {
	
	static Logger log = Logger.getLogger(BankManagementException.class);
	
	public BankManagementException(String msg){
		super(msg);
		
		log.info("Exception Handled in BankManagementException ");
		
		
	}

}
