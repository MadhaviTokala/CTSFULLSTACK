package com.cts.bankmanagement.service;

import com.cts.bankmanagement.vo.EducationLoanVo;

public interface ApplyEducationLoanService {
	
	public Long insertEducationLoanDetails(EducationLoanVo eduLoanVo);

}
