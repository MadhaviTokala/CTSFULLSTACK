package com.cts.bankmanagement.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bankmanagement.dao.ApplyEducationLoanDAO;
import com.cts.bankmanagement.vo.EducationLoanVo;

@Service
public class ApplyEducationLoanServiceImpl implements ApplyEducationLoanService{

	static Logger log = Logger.getLogger(ApplyEducationLoanServiceImpl.class);
	
	private ApplyEducationLoanDAO eduLoanDAO;
	
	@Autowired(required = true)
	public void setEduLoanDAO(ApplyEducationLoanDAO eduLoanDAO) {
		this.eduLoanDAO = eduLoanDAO;
	}


	@Override
	@Transactional
	public Long insertEducationLoanDetails(EducationLoanVo eduLoanVo) {
		
		
		return eduLoanDAO.insertEducationLoanDetails(eduLoanVo);
	}
	
	

}
