package com.cts.bankmanagement.service;

import com.cts.bankmanagement.vo.HomeLoanDetailsVo;

public interface ApplyHomeLoanService {

	public Long insertHomeLoanDetails(HomeLoanDetailsVo applyHomeLoanVo);

}
