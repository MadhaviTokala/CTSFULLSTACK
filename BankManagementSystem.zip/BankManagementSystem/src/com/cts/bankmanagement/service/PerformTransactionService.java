package com.cts.bankmanagement.service;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

public interface PerformTransactionService {
	
	public Double updateTransactionDetails(TransactionVO transactionVO) throws BankManagementException;

}
