package com.cts.bankmanagement.service;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bankmanagement.dao.PerformTransactionDAO;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

@Service
public class PerformTransactionServiceImpl implements PerformTransactionService {
	
	Logger LOG=Logger.getLogger(PerformTransactionServiceImpl.class);

	@Autowired(required=true)
	private PerformTransactionDAO performTransactionDAO;


	@Transactional
	public Double updateTransactionDetails(TransactionVO transactionVO) throws BankManagementException {
		
		LOG.info("In Service Class "+transactionVO.getAccountNumber());
		
		Double updatedBalance=performTransactionDAO.updateTransactionDetails(transactionVO);
		return updatedBalance;
	}

}
