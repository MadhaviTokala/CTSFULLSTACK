package com.cts.bankmanagement.service;

import org.springframework.stereotype.Service;

import com.cts.bankmanagement.vo.EducationLoanVo;

@Service
public interface ViewEducationLoanService {

	
	public EducationLoanVo retriveEducationLoanDetails(String educationLoanid , Long accountNumber);
}
