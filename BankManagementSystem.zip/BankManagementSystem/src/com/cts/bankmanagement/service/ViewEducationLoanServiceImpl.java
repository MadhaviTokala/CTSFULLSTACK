package com.cts.bankmanagement.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bankmanagement.dao.ViewEducationLoanDAO;
import com.cts.bankmanagement.vo.EducationLoanVo;

@Service
public class ViewEducationLoanServiceImpl implements ViewEducationLoanService{

	static Logger log  = Logger.getLogger(ViewEducationLoanServiceImpl.class);
	
	private ViewEducationLoanDAO educationLoanDAO;

	@Autowired(required = true)
	public void setEducationLoanDAO(ViewEducationLoanDAO educationLoanDAO) {
		this.educationLoanDAO = educationLoanDAO;
	}


	@Override
	@Transactional
	public EducationLoanVo retriveEducationLoanDetails(
			String educationLoanid, Long accountNumber) {
		
		EducationLoanVo list = educationLoanDAO.retrieveEducationLoanDetails(educationLoanid, accountNumber);
		
		return list;
	}
	
	

}
