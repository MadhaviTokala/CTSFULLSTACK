package com.cts.bankmanagement.service;


import com.cts.bankmanagement.vo.HomeLoanDetailsVo;


public interface ViewHomeLoanService {
	
	public HomeLoanDetailsVo retrieveHomeLoanDetails(String loanID, Long loanAccountNumber);

}
