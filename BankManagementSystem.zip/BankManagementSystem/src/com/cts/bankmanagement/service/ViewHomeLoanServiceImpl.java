package com.cts.bankmanagement.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bankmanagement.dao.ViewHomeLoanDAO;

import com.cts.bankmanagement.vo.HomeLoanDetailsVo;


@Service
public class ViewHomeLoanServiceImpl implements ViewHomeLoanService {
	
	
	static Logger log = Logger.getLogger(ViewHomeLoanServiceImpl.class);
	
    private ViewHomeLoanDAO viewHomeLoanDAO;
    
    @Autowired
	public void setViewHomeLoanDAO(ViewHomeLoanDAO viewHomeLoanDAO) {
		this.viewHomeLoanDAO = viewHomeLoanDAO;
	}




	@Override
	@Transactional
	public HomeLoanDetailsVo retrieveHomeLoanDetails(String loanID,
			Long loanAccountNumber) {
		
		return viewHomeLoanDAO.retrieveHomeLoanDetails(loanID, loanAccountNumber) ;
	}

}
