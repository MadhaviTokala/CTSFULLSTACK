package com.cts.bankmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bankmanagement.dao.ViewTransactionDAO;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;

@Service
public class ViewTransactionServiceImpl implements ViewTransactionService {
	
	Logger log=Logger.getLogger(ViewTransactionServiceImpl.class);

	@Autowired(required=true)
	private  ViewTransactionDAO viewTransactionDAO;
	
	
	@Transactional
	public List<TransactionVO> retrieveTransactionDetails(Long accountNumber,Long transactionId) throws BankManagementException {
		
		List<TransactionVO> transactionList=viewTransactionDAO.retrieveTransactionDetails(accountNumber,transactionId);
		
		return transactionList;
	}

}
