package com.cts.bankmanagement.vo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class EducationLoanVo {
	
	private String educationLoanId;
	
	@NotNull
	@Min(1000000000000000l)
	@Max(9999999999999999l)
	private Long accountNumber;
	
	private Long eduLoanAccountNumber;
	
	@NotNull
	private Long eduLoanAmount;
	
	@NotEmpty
	private String eduLoanApplyDate;
	
	@NotNull
	private Integer eduLoanDuration;
	
	@NotNull
	private Integer fatherAnnualIncome;
	
	@NotEmpty
	private String fatherName;
	
	@NotNull
	@Max(2000000L)
	private Integer courseFee;
	
	@NotEmpty
	private String courseName;
	
	@NotNull
	@Min(10000L)
	private Long idCardNumber;
	
	private String accountHolderName;
	
	private String userMessage;
	private String fatherNameMessage;
	private String courseFeeMessage;
	private String idCardMessage;
	
	
	
	
	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getIdCardMessage() {
		return idCardMessage;
	}

	public void setIdCardMessage(String idCardMessage) {
		this.idCardMessage = idCardMessage;
	}

	public String getFatherNameMessage() {
		return fatherNameMessage;
	}

	public void setFatherNameMessage(String fatherNameMessage) {
		this.fatherNameMessage = fatherNameMessage;
	}

	public String getCourseFeeMessage() {
		return courseFeeMessage;
	}

	public void setCourseFeeMessage(String courseFeeMessage) {
		this.courseFeeMessage = courseFeeMessage;
	}

	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getEducationLoanId() {
		return educationLoanId;
	}

	public void setEducationLoanId(String educationLoanId) {
		this.educationLoanId = educationLoanId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getEduLoanAccountNumber() {
		return eduLoanAccountNumber;
	}

	public void setEduLoanAccountNumber(Long eduLoanAccountNumber) {
		this.eduLoanAccountNumber = eduLoanAccountNumber;
	}

	public Long getEduLoanAmount() {
		return eduLoanAmount;
	}

	public void setEduLoanAmount(Long eduLoanAmount) {
		this.eduLoanAmount = eduLoanAmount;
	}

	public String getEduLoanApplyDate() {
		return eduLoanApplyDate;
	}

	public void setEduLoanApplyDate(String eduLoanApplyDate) {
		this.eduLoanApplyDate = eduLoanApplyDate;
	}

	public Integer getEduLoanDuration() {
		return eduLoanDuration;
	}

	public void setEduLoanDuration(Integer eduLoanDuration) {
		this.eduLoanDuration = eduLoanDuration;
	}

	public Integer getFatherAnnualIncome() {
		return fatherAnnualIncome;
	}

	public void setFatherAnnualIncome(Integer fatherAnnualIncome) {
		this.fatherAnnualIncome = fatherAnnualIncome;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Integer getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(Integer courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Long getIdCardNumber() {
		return idCardNumber;
	}

	public void setIdCardNumber(Long idCardNumber) {
		this.idCardNumber = idCardNumber;
	}
	
	
	

}
