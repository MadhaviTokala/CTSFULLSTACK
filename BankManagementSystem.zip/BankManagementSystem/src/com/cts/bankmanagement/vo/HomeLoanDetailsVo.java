package com.cts.bankmanagement.vo;


import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;



@Component
public class HomeLoanDetailsVo {

	
	private String LoanID;
	
	private String accountHolderName;

	@NotNull
	@Min(1000000000000000l)
	@Max(9999999999999999l)
	private Long accountNumber;
	
	
	private Long LoanAccountNumber;

	@NotNull
	private Long loanAmount;

	@NotEmpty
	private String loanApplyDate;

	@NotNull
	private Integer loanDuration;

	@NotNull
	private Long annualIncome;

	@NotEmpty
	private String companyName;

	@NotEmpty
	private String designation;

	@NotNull
	private Integer totalExp;

    @NotNull
	private Integer expCurrentComapny;

	private String userMessage;

	private String annIncomeMsg;


	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	
	public String getLoanID() {
		return LoanID;
	}

	public void setLoanID(String loanID) {
		LoanID = loanID;
	}

	public Long getLoanAccountNumber() {
		return LoanAccountNumber;
	}

	public void setLoanAccountNumber(Long loanAccountNumber) {
		LoanAccountNumber = loanAccountNumber;
	}

	public Long getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Long loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Long getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(Long annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getLoanApplyDate() {
		return loanApplyDate;
	}

	public void setLoanApplyDate(String loanApplyDate) {
		this.loanApplyDate = loanApplyDate;
	}

	public Integer getLoanDuration() {
		return loanDuration;
	}

	public void setLoanDuration(Integer loanDuration) {
		this.loanDuration = loanDuration;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Integer getTotalExp() {
		return totalExp;
	}

	public void setTotalExp(Integer totalExp) {
		this.totalExp = totalExp;
	}

	public Integer getExpCurrentComapny() {
		return expCurrentComapny;
	}

	public void setExpCurrentComapny(Integer expCurrentComapny) {
		this.expCurrentComapny = expCurrentComapny;
	}

	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getAnnIncomeMsg() {
		return annIncomeMsg;
	}

	public void setAnnIncomeMsg(String annIncomeMsg) {
		this.annIncomeMsg = annIncomeMsg;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

}
