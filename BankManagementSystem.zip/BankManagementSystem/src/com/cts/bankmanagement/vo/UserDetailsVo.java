package com.cts.bankmanagement.vo;

public class UserDetailsVo {
	
	
	private long accountNumber;
	
	
	private String accountType;
	
	
	private String accountHolderNmae;
	
	
	private String accountBalance;

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountHolderNmae() {
		return accountHolderNmae;
	}

	public void setAccountHolderNmae(String accountHolderNmae) {
		this.accountHolderNmae = accountHolderNmae;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	

}
